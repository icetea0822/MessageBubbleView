# MessageBubbleView
### 仿QQ未读消息气泡，可拖动删除。使用时需要在父布局属性中加入android:clipChildren="false"
